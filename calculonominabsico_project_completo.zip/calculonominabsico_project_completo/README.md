# Cálculo de Nómina Básico (Android App)

Ejercicio práctico desarrollado en **Android Studio** utilizando **Java**, basado en las directrices de la práctica del **IES Luis Braille** (autora: Laura Sacristán Matesanz).

## 🚀 Funcionalidades de la Aplicación
1. **Interfaz Gráfica (`activity_main.xml`)**:
   - Cabecera con título principal y logotipo del instituto (`IES Luis Braille`).
   - Campos de texto (`EditText`) para introducir los **días** y las **horas** trabajadas.
   - Casillas de verificación (`CheckBox`) para seleccionar si se desea visualizar el **Pago** y/o el **Pago con descuento** (aplicando un 10% de reducción si supera el sueldo base de 2.200 €).
   - Grupo de botones de opción (`RadioGroup` / `RadioButton`) para aplicar **Redondeo** o **No Redondeo** sobre las cantidades calculadas.
   - Botones de acción **CALCULAR** y **BORRAR**.

2. **Lógica de Programación (`MainActivity.java`)**:
   - Lectura y conversión de tipos (`Casting`) desde los campos de entrada de texto.
   - Cálculo del sueldo base multiplicando días, horas y la tarifa por hora (13,75 €).
   - Evaluación de condiciones con `if` para aplicar descuentos y redondeos mediante `Math.round()`.
   - Limpieza completa de campos y estados con el método `Borrar`.

---

## 🛠️ Cómo subir este proyecto a GitHub

Sigue estos pasos desde tu terminal (Git Bash, CMD o la terminal integrada de Android Studio):

1. **Inicializar el repositorio Git localmente en la carpeta del proyecto:**
   ```bash
   git init
   ```

2. **Añadir todos los archivos al área de preparación (staging):**
   ```bash
   git add .
   ```

3. **Realizar el primer commit:**
   ```bash
   git commit -m "Primer commit: Proyecto completo de calculo de nomina basico en Android"
   ```

4. **Conectar tu repositorio local con GitHub** (reemplaza la URL con la de tu repositorio creado en GitHub):
   ```bash
   git remote add origin https://github.com/tu-usuario/calculo-nomina-basico.git
   ```

5. **Subir los cambios a la rama principal (`main` o `master`):**
   ```bash
   git branch -M main
   git push -u origin main
   ```
